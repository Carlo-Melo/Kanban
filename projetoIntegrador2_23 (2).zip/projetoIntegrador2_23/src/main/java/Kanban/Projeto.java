package Kanban;

import java.util.ArrayList;
import java.util.Scanner;

public class Projeto {
    
    ArrayList<String> projeto = new ArrayList<>();
    Scanner input = new Scanner(System.in);
    
    private String[] nome;
    private int N;
    
    
    public Projeto(String nome){
        this.N =N;
        this.nome = new String[N];
    }
    
    public void setN(int N){
        this.N = 10;
    }

    public int getN(){
       return N;              
    }
    
    
    public void setNome (String nome){
        this.nome = new String[N];
    }

    public String[] getNome(){
       return nome;              
    }
    
    //funções
    public void CadastrarProjeto(){
        
    }

    public int ProjetosCriados(Scanner input){
        int escolha = 1;
        do{    
                System.out.println("••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••");
                System.out.println("  MARK TASK                                                                                                           |");
                System.out.println("••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••");
                System.out.println("                                                                                                                      |");
                System.out.println("                                                                                                                      |");
                System.out.println("                                                                                                                      |");
                System.out.println("1 - "+nome[0]+"                                                                                                         |");
                System.out.println("2 - "+nome[1]+"                                                                                                         |");
                System.out.println("3 - "+nome[1]+"                                                                                                         |");
                System.out.println("                                                                                                                      |");
                System.out.println("                                                                                                                      |");
                System.out.println("                                                                                                                      |");
                System.out.println("                                                                                                                      |");
                System.out.println("                                                                                                                      |");
                System.out.println("                                                                                                                      |");
                System.out.println("                                                                                                                      |");
                System.out.println("                                                                                                                      |");
                System.out.println("                                                                                                                      |");
                System.out.println("1 - EXIBIR PROJETO                                                                                                                    |");
                System.out.println("                                                                                                                      |");
                System.out.println("                                                                                                                      |");
                System.out.println("0 - MENU                                                                                                              |");
                System.out.println("                                                                                                                      |");
                System.out.println("                                                                                                                      |");
                escolha = input.nextInt();
                if(escolha == 1){
                    //metodo atividade()
                    
                }
                if(escolha == 0){
                    escolha = 0;
                }
        }while(escolha == 0);        
        return escolha;
    }
    
}