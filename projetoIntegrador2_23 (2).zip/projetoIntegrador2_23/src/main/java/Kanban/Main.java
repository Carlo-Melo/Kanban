package Kanban;

import java.util.Scanner;

public class Main {
    
    public static void main(String[] args) {
        
        Scanner input = new Scanner(System.in);
        
        LimpaChat limpachat = new LimpaChat();
        
        LimpaChat.clearTerminal();
               
        int escolha = 2;
        
        while(escolha != 0){
        System.out.println("1 - CADASTRAR");
        System.out.println("2 - LOGIN\n");
        escolha = input.nextInt();
            if(escolha==1){
                System.out.println("Digite o nome de usuário:");
                String nomeUsuario = input.next();
                System.out.println("Digite a senha:");
                String senha = input.next();
                Cadastro cadastro = new Cadastro(escolha, nomeUsuario, senha);
                cadastro.cadastrarUsuario();
            }                
            if(escolha==2){
                System.out.println("Digite o nome de usuário:");
                String nomeUsuario = input.next();
                System.out.println("Digite a senha:");
                String senha = input.next();
                Cadastro login = new Cadastro(escolha, nomeUsuario, senha);
                login.realizarLogin();                  
                if(login.Escolha()==0){
                escolha = 0;
                }
            }
        }
        escolha = 1;
        do{
            LimpaChat.clearTerminal();
            escolha = 1;
            System.out.println("••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••");
            System.out.println("  ____   ____           _____           _______    _____     __________             _____           _______    _____  |");
            System.out.println(" |   |   )   )         /     |         )       )   )    )   |    ____   )          /     |         )       )   )    ) |");
            System.out.println(" |   |  )   )         /  __  |        /        |  /    /    |   |    )   )        /  __  |        /        |  /    /  |");
            System.out.println(" |   |_)   )         /  /  | |       /     /|  | /    /     |   |___)   )        /  /  | |       /     /|  | /    /   |");
            System.out.println(" |        )         /  /___| |      /     / |  |/    /      |          )        /  /___| |      /     / |  |/    /    |");
            System.out.println(" |        )        /         |     /     /  |       /       |    __    )       /         |     /     /  |       /     |");
            System.out.println(" |   |)    )      /   ____   |    /     /   |      /        |   |  )    )     /   ____   |    /     /   |      /      |");
            System.out.println(" |   | |    |    /   /    |  |   /     /    |     /         |   |___)    )   /   /    |  |   /     /    |     /       |");
            System.out.println(" |___|  )____)  /___/     |__|  /_____/     |____/          |___________)   /___/     |__|  /_____/     |____/        |");
            System.out.println("••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••");
            System.out.println("  MARK TASK                                                                                                           |");
            System.out.println("••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••");
            System.out.println("                                                                                                                      |");
            System.out.println("                                                                                                                      |");
            System.out.println("                                                                                                                      |");
            System.out.println("                                                                                                                      |");
            System.out.println("1 - CRIAR PROJETO                                                                                                          |");
            System.out.println("2 - PROJETOS                                                                                                     |");
            System.out.println("                                                                                                                      |");
            System.out.println("                                                                                                                      |");
            System.out.println("0 - MENU                                                                                                              |");
            System.out.println("                                                                                                                      |");
            System.out.println("                                                                                                                      |");
            escolha = input.nextInt();
            if(escolha==1){
                LimpaChat.clearTerminal();
                //metodo CadastrarProjeto()
                
            }
            if(escolha==2){
                LimpaChat.clearTerminal();
                //metodo ProjetosCriados()
                
            }
            
        }while(escolha == 0);
        
        LimpaChat.clearTerminal();
        System.out.println("•••••• ");
        int N = input.nextInt();        
        Atividade atividade = new Atividade(N);
        LimpaChat.clearTerminal();
        atividade.lerDados(input);
        LimpaChat.clearTerminal();
        atividade.quadro();
       
    }
}