package Kanban;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Cadastro {
    public static Map<String, String> usuarios = new HashMap<>();
    private int escolha;
    private String nomeUsuario;
    private String senha;
    
public Cadastro(int escolha, String nomeUsuario, String senha){
    this.escolha = escolha;
    this.nomeUsuario = nomeUsuario;
    this.senha = senha;   
}

public void setNomeUsuario (String nomeUsuario){
        this.nomeUsuario = nomeUsuario;
    }

    public String getNomeUsuario(){
       return nomeUsuario;              
    }

public void setSenha (String senha) {
        this.senha = senha;
    }

    public String getSenha(){
       return senha;              
    }
    
public void setEscolha (int escolha){
        this.escolha = escolha;
    }

    public int getEscolha(){
       return escolha;              
    } 

    public void cadastrarUsuario() {
        usuarios.put(this.nomeUsuario,this.senha);
        System.out.println("Usuário cadastrado com sucesso!");
    }
    
      void realizarLogin() {
        if (usuarios.containsKey(this.nomeUsuario) && usuarios.get(this.nomeUsuario).equals(this.senha)) {
            System.out.println("Login bem-sucedido! Bem-vindo, " + this.nomeUsuario + ".");
        } else {
            System.out.println("Nome de usuário ou senha incorretos. Tente novamente.");     
        }        
    }
      
    public int Escolha(){
        if (usuarios.containsKey(this.nomeUsuario) && usuarios.get(this.nomeUsuario).equals(this.senha)){
            return this.escolha = 0;
        }
        return escolha;         
    }
}


    

     