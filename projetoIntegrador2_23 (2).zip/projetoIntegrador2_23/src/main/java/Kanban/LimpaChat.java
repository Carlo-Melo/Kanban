package Kanban;

public class LimpaChat {
    
    public static void clearTerminal() {
        for (int i = 0; i < 50; i++){
            System.out.println("");
        }
    }
    
}
