package Kanban;

//import java.time.Instant;
//import java.time.LocalDate;
//import java.time.LocalDateTime;
//import java.time.format.DateTimeFormatter;

public class Acao {
    
    private String[] Acao;
    private int N;
    
    
    public Acao(String Acao){
        this.N =N;
        this.Acao = new String[N];
    }
    
    public void setN(int N){
        this.N = N;
    }

    public int getN(){
       return N;              
    }
    
    
    public void setAcao (String Acao){
        this.Acao = new String[N];
    }

    public String[] getAcao(){
       return Acao;              
    }    
}
    

