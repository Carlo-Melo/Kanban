package model.entities;

import java.util.Scanner;

public class tarefa {
    public int N;
    public String[] nome;
    public int[] idade;
    public float[] altura;

    public tarefa(int N) {
        this.N = N;
        nome = new String[N];
        idade = new int[N];
        altura = new float[N];
        
    }

    public void lerDados(Scanner input) {
        for (int i = 0; i < N; i++) {
            System.out.println("Informe o " + (i + 1) + "º ação: ");
            nome[i] = input.next();
            System.out.println("Informe a " + (i + 1) + "º dia inicio: ");
            altura[i] = input.nextFloat();
            System.out.println("Informe a " + (i + 1) + "º dia limite: ");
            idade[i] = input.nextInt();
            System.out.println("==========================================");
        }
    }

    public void exibirDados() {
        float soma = 0;
        int contador = 0;
        int porcentagem;
        for (int i = 0; i < N; i++){
            soma = (soma + altura[i]);
        }
        float media;
        media = soma/N;
        System.out.println("Altura média: "+media);
        for (int i = 0; i < N; i++){            
            if(idade[i] < 16){
            contador = contador + 1;
            }
        }
        porcentagem = ((contador*100) / N);
        System.out.println("Pessoas com menos de 16 anos: "+porcentagem+"%");
            for (int i = 0; i < N; i++){
            if(idade[i] < 16){
            System.out.println(nome[i]);          
            }
            
        }
        
        
    }
    
}
