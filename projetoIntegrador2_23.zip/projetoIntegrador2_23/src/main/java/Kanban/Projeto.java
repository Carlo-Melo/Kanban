package Kanban;


public class Projeto {
    
    private String[] nome;
    private int N;
    
    
     public Projeto(String nome){
        this.N = N;
        this.nome = new String[N];
    }
    
    public void setAcao(String nomeProjeto){
        this.nome = nome;
    }

    public String[] getAcao(){
       return nome;              
    }    
}