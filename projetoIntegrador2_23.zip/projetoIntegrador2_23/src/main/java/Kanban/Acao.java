package Kanban;

//import java.time.Instant;
//import java.time.LocalDate;
//import java.time.LocalDateTime;
//import java.time.format.DateTimeFormatter;

public class Acao {
    
    private String[] Acao;
    private int N;
    
    
    public Acao(String Acao){
        this.Acao = new String[N];
    }
    
    public void setAcao(String nomeProjeto){
        this.Acao = Acao;
    }

    public String[] getAcao(){
       return Acao;              
    }    
}
    

