package Kanban;

import java.util.Scanner;

public class Atividade {
    public int N;
    String[] atividade;
    public int[] idade;
    public float[] altura;

    public Atividade(int N) {
        this.N = N;
        atividade = new String[N];
        idade = new int[N];
        altura = new float[N];
        
    }

    public void lerDados(Scanner input) {
        for (int i = 0; i < N; i++) {
            System.out.println("Informe a " + (i + 1) + "º Atividade: ");
            atividade[i] = input.next();
            System.out.println("Informe a " + (i + 1) + "º dia inicio: ");
            altura[i] = input.nextFloat();
            System.out.println("Informe a " + (i + 1) + "º dia limite: ");
            idade[i] = input.nextInt();
            System.out.println("==========================================");
        }
    }

    
    
    public void quadro() {
        
        System.out.println("|========================|=========================|=========================|");
        System.out.println("•         A FAZER         •         FAZENDO         •          FEITO          •");
        System.out.println("|••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••|");        
        System.out.println("|                        |                         |                         |");
        System.out.println("|                        |                         |                         |");
        System.out.println("|                        |                         |                         |");
        System.out.println("|                        |                         |                         |");
        System.out.println("|                        |                         |                         |");
        System.out.println("|                        |                         |                         |");
        System.out.println("|                        |                         |                         |");
        System.out.println("|                        |                         |                         |");
        System.out.println("|                        |                         |                         |");
        System.out.println("|                        |                         |                         |");
        System.out.println("|                        |                         |                         |");
        
        
        
    }
    
}