package Kanban;


public class Enum {
    public Enum(){
        
    }
     public void quadro() {
        
        System.out.println("|========================= =========================== ===========================|");
        System.out.println("•         A FAZER          •         FAZENDO           •          FEITO            •");
        System.out.println("|========================= =========================== ===========================|");
        System.out.println("|                          |                          |                           |");
        System.out.println("|                          |                          |                           |");
        System.out.println("|                          |                          |                           |");
        System.out.println("|                          |                          |                           |");
        System.out.println("|                          |                          |                           |");
        System.out.println("|                          |                          |                           |");
        System.out.println("|                          |                          |                           |");
        System.out.println("|                          |                          |                           |");
        System.out.println("|                          |                          |                           |");
        System.out.println("|                          |                          |                           |");
        System.out.println("|                          |                          |                           |");
        System.out.println("|                          |                          |                           |");
        System.out.println("|                          |                          |                           |");
        System.out.println("|                          |                          |                           |");
        System.out.println("|                          |                          |                           |");
        System.out.println("|=================================================================================|");

        
        
        
    }
    
}
