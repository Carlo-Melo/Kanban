package Kanban;

import java.util.Scanner;

public class Main {
    
    public static void main(String[] args) {
        
        Scanner input = new Scanner(System.in);
        
        LimpaChat limpachat = new LimpaChat();
        
        LimpaChat.clearTerminal();
               
        int escolha = 2;
        
        while(escolha != 0){
        System.out.println("1 - CADASTRAR");
        System.out.println("2 - LOGIN\n");
        escolha = input.nextInt();
            if(escolha==1){
                System.out.println("Digite o nome de usuário:");
                String nomeUsuario = input.next();
                System.out.println("Digite a senha:");
                String senha = input.next();
                Cadastro cadastro = new Cadastro(escolha, nomeUsuario, senha);
                cadastro.cadastrarUsuario();
            }                
            if(escolha==2){
                System.out.println("Digite o nome de usuário:");
                String nomeUsuario = input.next();
                System.out.println("Digite a senha:");
                String senha = input.next();
                Cadastro login = new Cadastro(escolha, nomeUsuario, senha);
                login.realizarLogin();                  
                if(login.Escolha()==0){
                escolha = 0;
                }
            }
        }
        int n = 5;
        
        String projetos[] = new String[n];
        projetos[0] = "";
        projetos[1] = "";
        projetos[2] = "";
        projetos[3] = "";
        Projeto projeto = new Projeto(projetos, n);
        do{
            do{
                do{
                    LimpaChat.clearTerminal();
                    escolha = 1;
                    System.out.println("••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••");
                    System.out.println("  ____   ____           _____           _______    _____     __________             _____           _______    _____  |");
                    System.out.println(" |   |   )   )         /     |         )       )   )    )   |    ____   )          /     |         )       )   )    ) |");
                    System.out.println(" |   |  )   )         /  __  |        /        |  /    /    |   |    )   )        /  __  |        /        |  /    /  |");
                    System.out.println(" |   |_)   )         /  /  | |       /     /|  | /    /     |   |___)   )        /  /  | |       /     /|  | /    /   |");
                    System.out.println(" |        )         /  /___| |      /     / |  |/    /      |          )        /  /___| |      /     / |  |/    /    |");
                    System.out.println(" |        )        /         |     /     /  |       /       |    __    )       /         |     /     /  |       /     |");
                    System.out.println(" |   |)    )      /   ____   |    /     /   |      /        |   |  )    )     /   ____   |    /     /   |      /      |");
                    System.out.println(" |   | |    |    /   /    |  |   /     /    |     /         |   |___)    )   /   /    |  |   /     /    |     /       |");
                    System.out.println(" |___|  )____)  /___/     |__|  /_____/     |____/          |___________)   /___/     |__|  /_____/     |____/        |");
                    System.out.println("••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••");
                    System.out.println("  MARK TASK                                                                                                           |");
                    System.out.println("••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••");
                    System.out.println("                                                                                                                      |");
                    System.out.println("                                                                                                                      |");
                    System.out.println("                                                                                                                      |");
                    System.out.println("                                                                                                                      |");
                    System.out.println("1 - PROJETOS                                                                                                          |");
                    System.out.println("2 - CRIAR PROJETO                                                                                                     |");
                    System.out.println("                                                                                                                      |");
                    System.out.println("                                                                                                                      |");
                    System.out.println("0 - MENU                                                                                                              |");
                    System.out.println("                                                                                                                      |");
                    System.out.println("                                                                                                                      |");
                    escolha = input.nextInt();
                    if(escolha==2){
                        LimpaChat.clearTerminal();
                        projeto.CadastrarProjeto(input);
                        escolha = 0;
                    }
                }while(escolha == 0);



                if(escolha==1){
                    LimpaChat.clearTerminal();
                    System.out.println("••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••");
                    System.out.println("  ____   ____           _____           _______    _____     __________             _____           _______    _____  |");
                    System.out.println(" |   |   )   )         /     |         )       )   )    )   |    ____   )          /     |         )       )   )    ) |");
                    System.out.println(" |   |  )   )         /  __  |        /        |  /    /    |   |    )   )        /  __  |        /        |  /    /  |");
                    System.out.println(" |   |_)   )         /  /  | |       /     /|  | /    /     |   |___)   )        /  /  | |       /     /|  | /    /   |");
                    System.out.println(" |        )         /  /___| |      /     / |  |/    /      |          )        /  /___| |      /     / |  |/    /    |");
                    System.out.println(" |        )        /         |     /     /  |       /       |    __    )       /         |     /     /  |       /     |");
                    System.out.println(" |   |)    )      /   ____   |    /     /   |      /        |   |  )    )     /   ____   |    /     /   |      /      |");
                    System.out.println(" |   | |    |    /   /    |  |   /     /    |     /         |   |___)    )   /   /    |  |   /     /    |     /       |");
                    System.out.println(" |___|  )____)  /___/     |__|  /_____/     |____/          |___________)   /___/     |__|  /_____/     |____/        |");
                    System.out.println("••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••");
                    System.out.println("  MARK TASK                                                                                                           |");
                    System.out.println("••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••");
                    System.out.println("                                                                                                                      ");
                    System.out.print("");
                    System.out.print(" 1 - "+projeto.P4()+"\n");                                                                                        
                    System.out.print("");
                    System.out.print(" 2 - "+projeto.P0()+"\n");
                    System.out.print("");
                    System.out.print(" 3 - "+projeto.P1()+"\n");
                    System.out.print("");
                    System.out.print(" 4 - "+projeto.P2()+"\n");
                    System.out.print("");
                    System.out.print(" 5 - "+projeto.P3()+"\n");
                    System.out.println("                                                                                                                      ");
                    System.out.println("                                                                                                                      ");
                    System.out.println(" 0 - MENU                                                                                                             ");
                    System.out.println("                                                                                                                      ");
                    System.out.println("                                                                                                                      ");
                    escolha = input.nextInt();
                }
            }while(escolha == 0);        
        LimpaChat.clearTerminal();
        Enum a = new Enum();
        a.quadro();
        System.out.println("\n0 - MENU\n\n");
        escolha = input.nextInt();
        }while(escolha == 0);               
    }
}