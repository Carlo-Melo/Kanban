

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class Acao {

    private String[] acoes;
    private int N;
    private Date dataInicio;
    private Date dataFim;
    private SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");

    public Acao(int N) {
        this.N = N;
        this.acoes = new String[N];
    }

    public void setN(int N) {
        this.N = N;
    }

    public int getN() {
        return N;
    }

    public void setAcoes(String[] acoes) {
        this.acoes = acoes;
    }

    public String[] getAcoes() {
        return acoes;
    }

    public void setDataInicio() {
        while (true) {
            try {
                // Solicita ao usuário para inserir a data de início
                System.out.print("Insira a data de início (DD/MM/AAAA): ");
                String dataInicioStr = new Scanner(System.in).next();
                this.dataInicio = dateFormat.parse(dataInicioStr);
                break; // Sai do loop se a conversão for bem-sucedida
            } catch (ParseException e) {
                // Trata exceção se o formato da data estiver incorreto
                System.out.println("Formato de data inválido. Tente novamente.");
            }
        }
    }

    public Date getDataInicio() {
        return dataInicio;
    }

    public void setDataFim() {
        while (true) {
            try {
                // Solicita ao usuário para inserir a data de fim
                System.out.print("Insira a data de fim (DD/MM/AAAA): ");
                String dataFimStr = new Scanner(System.in).next();
                this.dataFim = dateFormat.parse(dataFimStr);

                // Verifica se a data final é maior ou igual à data inicial
                if (dataFim.compareTo(dataInicio) < 0) {
                    System.out.println("Data de fim menor que a data de início. Tente novamente.");
                } else {
                    break; // Sai do loop se a conversão e verificação forem bem-sucedidas
                }
            } catch (ParseException e) {
                // Trata exceção se o formato da data estiver incorreto
                System.out.println("Formato de data inválido. Tente novamente.");
            }
        }
    }

    public Date getDataFim() {
        return dataFim;
    }

    public void exibirDatas() {
        // Exibe as datas formatadas
        System.out.println("Data de Início: " + (dataInicio != null ? dateFormat.format(dataInicio) : "Não definida"));
        System.out.println("Data de Fim: " + (dataFim != null ? dateFormat.format(dataFim) : "Não definida"));
    }
}


