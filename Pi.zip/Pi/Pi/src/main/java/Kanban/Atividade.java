package Kanban;

import java.util.Scanner;

public class Atividade {
    
    private String[] atividades;
    private int N;

    public Atividade(String[] atividades, int N) {
        this.atividades = new String[N];
        this.N = N;
    }
    
    public void setN (int N) {
        this.N = N;
    }
    
    public int getN () {
        return N;
    }
    
    public void setAtivides(String[] projetos) {
         this.atividades = new String[N];    
    }
    
    public String[] geAtividades() {
        return atividades;
    }
    
    //funções

    public void lerDados(Scanner input) {     
    }
  
   
    
}