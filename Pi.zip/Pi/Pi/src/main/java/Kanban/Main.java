package Kanban;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        LimpaChat limpachat = new LimpaChat();
        LimpaChat.clearTerminal();
        String escolha = "2";
        String logado = "";
        ArrayList<Empresa> cadastros = new ArrayList<>();
        while (!"0".equals(escolha)) {
            System.out.println("1 - CADASTRAR");
            System.out.println("2 - LOGIN\n");
            escolha = input.nextLine();
            if ("1".equals(escolha)) {
                System.out.println("Digite o nome de usuário:");
                String nomeUsuario = input.nextLine();
                System.out.println("Digite a senha:");
                String senha = input.nextLine();
                cadastros.add(new Empresa(nomeUsuario, senha));
            }
            if ("2".equals(escolha)) {
                System.out.println("Digite o nome de usuário:");
                String nomeUsuario = input.nextLine();
                System.out.println("Digite a senha:");
                String senha = input.nextLine();
                for (Empresa cdt:cadastros) {
                    if (cdt.getNomeUsuario().equals(nomeUsuario)) {
                        if (cdt.realizarLogin(senha)) {
                            escolha = "0";
                            logado = nomeUsuario;
                        }
                    }
                }
                if ("0".equals(escolha)) {
                    escolha = "0";
                }
            }
        }
//        int n = 5;
//        String projetos[] = new String[n];
//        projetos[0] = "Teste";
//        projetos[1] = "";
//        projetos[2] = "";
//        projetos[3] = "";
//        projetos[4] = "";

        do {
            do {
                do {
                    LimpaChat.clearTerminal();
                    escolha = "1";
                    System.out.println("••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••");
                    System.out.println("  ____   ____           _____           _______    _____     __________             _____           _______    _____  |");
                    System.out.println(" |   |   )   )         /     |         )       )   )    )   |    ____   )          /     |         )       )   )    ) |");
                    System.out.println(" |   |  )   )         /  __  |        /        |  /    /    |   |    )   )        /  __  |        /        |  /    /  |");
                    System.out.println(" |   |_)   )         /  /  | |       /     /|  | /    /     |   |___)   )        /  /  | |       /     /|  | /    /   |");
                    System.out.println(" |        )         /  /___| |      /     / |  |/    /      |          )        /  /___| |      /     / |  |/    /    |");
                    System.out.println(" |        )        /         |     /     /  |       /       |    __    )       /         |     /     /  |       /     |");
                    System.out.println(" |   |)    )      /   ____   |    /     /   |      /        |   |  )    )     /   ____   |    /     /   |      /      |");
                    System.out.println(" |   | |    |    /   /    |  |   /     /    |     /         |   |___)    )   /   /    |  |   /     /    |     /       |");
                    System.out.println(" |___|  )____)  /___/     |__|  /_____/     |____/          |___________)   /___/     |__|  /_____/     |____/        |");
                    System.out.println("••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••");
                    System.out.println("  MARK TASK                                                                                                           |");
                    System.out.println("••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••");
                    System.out.println("                                                                                                                      |");
                    System.out.println("                                                                                                                      |");
                    System.out.println("                                                                                                                      |");
                    System.out.println("                                                                                                                      |");
                    System.out.println("1 - PROJETOS                                                                                                          |");
                    System.out.println("2 - GERAR RELATORIO                                                                                                   |");
                    System.out.println("                                                                                                                      |");
                    System.out.println("                                                                                                                      |");
                    System.out.println("                                                                                                                      |");
                    System.out.println("0 - MENU                                                                                                              |");
                    System.out.println("                                                                                                                      |");
                    System.out.println("                                                                                                                      |");
                    escolha = input.nextLine();
                    System.out.println(escolha);
//=============================================================================================================================================================================================                   
//=============================================================================================================================================================================================
//=============================================================================================================================================================================================
                    if("admin".equals(escolha)){
                        while (!"0".equals(escolha)){
                            Admin.Admin();
                            escolha = input.nextLine();
                            if (escolha.equals("2")) {
                                Empresa atual = null;
                                for (Empresa cdt:cadastros) {
                                    if (logado.equals(cdt.getNomeUsuario())) {
                                        atual = cdt;
                                    }
                                }
                                LimpaChat.clearTerminal();
                                for (int i = 0; i < atual.getProjetos().length; i++) {
                                    atual.getProjetos()[0] = "Projeto Integrador";
                                    if (atual.getProjetos()[i] == null) {
                                        System.out.println("Insira o nome do projeto:");
                                        atual.getProjetos()[i] = input.nextLine();                                   
                                        break;
                                    }
                                }
                            }
                            if(escolha.equals("1")){
                                LimpaChat.clearTerminal();
                                System.out.println("••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••");
                                System.out.println("  ____   ____           _____           _______    _____     __________             _____           _______    _____  |");
                                System.out.println(" |   |   )   )         /     |         )       )   )    )   |    ____   )          /     |         )       )   )    ) |");
                                System.out.println(" |   |  )   )         /  __  |        /        |  /    /    |   |    )   )        /  __  |        /        |  /    /  |");
                                System.out.println(" |   |_)   )         /  /  | |       /     /|  | 1/    /     |   |___)   )        /  /  | |       /     /|  | /    /   |");
                                System.out.println(" |        )         /  /___| |      /     / |  |/    /      |          )        /  /___| |      /     / |  |/    /    |");
                                System.out.println(" |        )        /         |     /     /  |       /       |    __    )       /         |     /     /  |       /     |");
                                System.out.println(" |   |)    )      /   ____   |    /     /   |      /        |   |  )    )     /   ____   |    /     /   |      /      |");
                                System.out.println(" |   | |    |    /   /    |  |   /     /    |     /         |   |___)    )   /   /    |  |   /     /    |     /       |");
                                System.out.println(" |___|  )____)  /___/     |__|  /_____/     |____/          |___________)   /___/     |__|  /_____/     |____/        |");
                                System.out.println("••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••");
                                System.out.println(" '"
                                        + " MARK TASK                                                                                                           |");
                                System.out.println("••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••");
                                System.out.println("                                                                                                                      ");
                                System.out.print("");
                                System.out.print("");
                                Empresa atual = null;
                                for (Empresa cdt:cadastros) {
                                    if (logado.equals(cdt.getNomeUsuario())) {
                                        atual = cdt;
                                    }
                                }
                                for (int i = 0; i < atual.getProjetos().length; i++) {
                                    if (atual.getProjetos()[i] == null) {
                                        continue;
                                    }
                                    System.out.println((i+1)+" - "+atual.getProjetos()[i]);
                                }
                                System.out.print("");
                                System.out.print("");
                                System.out.print("");
                                System.out.print("");
                                System.out.print("");
                                System.out.print("");
                                System.out.print("");
                                System.out.println("                                                                                                                      ");
                                System.out.println("                                                                                                                      ");
                                System.out.println("0 - MENU                                                                                                             ");
                                System.out.println("                                                                                                                      ");
                                System.out.println("                                                                                                                      ");
                                escolha = input.nextLine();
                            }
                            
                            if(escolha.equals("3")){
                                limpachat.clearTerminal();
                                Empresa atual = null;
                                for (Empresa emp:cadastros) {
                                    if (logado.equals(emp.getNomeUsuario()))  {
                                        atual = emp;
                                        break;
                                    }
                                }
                                for (int n = 0; n < atual.getProjetos().length; n++) {
                                    if (null == atual.getProjetos()[n]) {
                                        continue;
                                    }
                                    System.out.println((n+1)+" - "+atual.getProjetos()[n]);
                                }
                                System.out.println("");
                                System.out.println("Escolha um projeto (-1 cancela) : ");
                                int escolhaProjeto = Integer.parseInt(input.nextLine()) - 1;
                                if (escolhaProjeto < 0 || escolhaProjeto > 4) {
                                    continue;
                                }
                                if (atual.getProjetos()[escolhaProjeto] != null) {
                                    System.out.println("Nome da Atividade: ");
                                    String nomeAtividade = input.nextLine();
                                    atual.adicionarAtividade(escolhaProjeto, nomeAtividade);
                                }                               
                            }
                        }
                    }
                } while ("0".equals(escolha));
//=============================================================================================================================================================================================                    
//=============================================================================================================================================================================================                   
//=============================================================================================================================================================================================//=============================================================================================================================================================================================                  
                if ("1".equals(escolha)) {
                    LimpaChat.clearTerminal();
                    System.out.println("••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••");
                    System.out.println("  ____   ____           _____           _______    _____     __________             _____           _______    _____  |");
                    System.out.println(" |   |   )   )         /     |         )       )   )    )   |    ____   )          /     |         )       )   )    ) |");
                    System.out.println(" |   |  )   )         /  __  |        /        |  /    /    |   |    )   )        /  __  |        /        |  /    /  |");
                    System.out.println(" |   |_)   )         /  /  | |       /     /|  | /    /     |   |___)   )        /  /  | |       /     /|  | /    /   |");
                    System.out.println(" |        )         /  /___| |      /     / |  |/    /      |          )        /  /___| |      /     / |  |/    /    |");
                    System.out.println(" |        )        /         |     /     /  |       /       |    __    )       /         |     /     /  |       /     |");
                    System.out.println(" |   |)    )      /   ____   |    /     /   |      /        |   |  )    )     /   ____   |    /     /   |      /      |");
                    System.out.println(" |   | |    |    /   /    |  |   /     /    |     /         |   |___)    )   /   /    |  |   /     /    |     /       |");
                    System.out.println(" |___|  )____)  /___/     |__|  /_____/     |____/          |___________)   /___/     |__|  /_____/     |____/        |");
                    System.out.println("••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••");
                    System.out.println("  MARK TASK                                                                                                           |");
                    System.out.println("••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••");
                    System.out.println("                                                                                                                      ");
                    System.out.print("");
                    System.out.print("");
                    Empresa atual = null;
                    for (Empresa cdt:cadastros) {
                        if (logado.equals(cdt.getNomeUsuario())) {
                            atual = cdt;
                        }
                    }
                    for (int i = 0; i < atual.getProjetos().length; i++) {
                        if (atual.getProjetos()[i] == null) {
                            continue;
                        }
                        System.out.println((i+1)+" - "+atual.getProjetos()[i]);
                    }
                    System.out.print("");
                    System.out.print("");
                    System.out.print("");
                    System.out.print("");
                    System.out.print("");
                    System.out.print("");
                    System.out.print("");
                    System.out.println("                                                                                                                      ");
                    System.out.println("                                                                                                                      ");
                    System.out.println("0 - MENU                                                                                                             ");
                    System.out.println("                                                                                                                      ");
                    System.out.println("                                                                                                                      ");
                    escolha = input.nextLine();
                }
//                if("2".equals(escolha)){
//                    LimpaChat.clearTerminal();1
//                    Relatorio.Relatorio();
//                    
//                    System.out.println("\n0 - MENU\n\n");
//                    escolha = input.nextLine();
//                }
            }while ("0".equals(escolha));
            LimpaChat.clearTerminal();
            Empresa atual = null;
            for (Empresa emp:cadastros) {
                if (logado.equals(emp.getNomeUsuario()))  {
                    atual = emp;
                    break;
                }
            }
            Quadro.quadro(atual.getAtividades()[Integer.parseInt(escolha) - 1], atual.getPorcentagens()[Integer.parseInt(escolha) - 1]);            
            System.out.println("\n\n\n0 - MENU\n\n");

            System.out.println("DIGITE O NUMERO DA ATIVIDADE: ");       
            String AttEscolha = input.nextLine();
            while (true) {
                LimpaChat.clearTerminal();
                Quadro.quadro(atual.getAtividades()[Integer.parseInt(escolha) - 1], atual.getPorcentagens()[Integer.parseInt(escolha) - 1]);            
                System.out.println(atual.getAtividades()[Integer.parseInt(escolha)-1][Integer.parseInt(AttEscolha)]);
                System.out.println("1 - AUMENTAR");
                System.out.println("2 - DIMINUIR");
                System.out.println("\n\n0 - VOLTAR\n\n");
                String escolhaMod = input.nextLine();
                if ("0".equals(escolhaMod)) {
                    break;
                }
                if ("1".equals(escolhaMod)) {
                    atual.aumentarPorcentagem(Integer.parseInt(escolha)-1, Integer.parseInt(AttEscolha)-1);
                }
                if ("2".equals(escolhaMod)) {
                    atual.diminuirPorcentagem(Integer.parseInt(escolha)-1, Integer.parseInt(AttEscolha)-1);                    
                }
            }
//            if(){
//                LimpaChat.clearTerminal();
//                System.out.println(" "+(atividade nome)+"                                                        ");
//            }
//            if(){
//                LimpaChat.clearTerminal();   
//                System.out.println("  "+(atividade nome)+                                                      ");
//
//            }
//            if(){
//                LimpaChat.clearTerminal(); 
//                System.out.println(" "+(atividade nome)+                                                       ");
//
//            }          
        } while ("0".equals(escolha));
    }
}
