
package Kanban;


public class Relatorio {
    public static void Relatorio() {
        System.out.println("RELATORIO:                  ");
        System.out.println("|========================= =========================== ===========================|");
        System.out.println("•                                                                                  •");
        System.out.println("|========================= =========================== ===========================|");
        System.out.println("•                                                                                  •");    
        System.out.println("|========================= =========================== ===========================|");
        System.out.println("•                                                                                  •");
        System.out.println("•                                                                                  •");
        System.out.println("•                                                                                  •");
        System.out.println("•                                                                                  •");
        System.out.println("•                                                                                  •");
        System.out.println("•                                                                                  •");
              
    }
}
