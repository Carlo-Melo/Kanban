package Kanban;


public class Admin {
    public static void Admin() {

        System.out.println("••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••");
        System.out.println("  ____   ____           _____           _______    _____     __________             _____           _______    _____  |");
        System.out.println(" |   |   )   )         /     |         )       )   )    )   |    ____   )          /     |         )       )   )    ) |");
        System.out.println(" |   |  )   )         /  __  |        /        |  /    /    |   |    )   )        /  __  |        /        |  /    /  |");
        System.out.println(" |   |_)   )         /  /  | |       /     /|  | /    /     |   |___)   )        /  /  | |       /     /|  | /    /   |");
        System.out.println(" |        )         /  /___| |      /     / |  |/    /      |          )        /  /___| |      /     / |  |/    /    |");
        System.out.println(" |        )        /         |     /     /  |       /       |    __    )       /         |     /     /  |       /     |");
        System.out.println(" |   |)    )      /   ____   |    /     /   |      /        |   |  )    )     /   ____   |    /     /   |      /      |");
        System.out.println(" |   | |    |    /   /    |  |   /     /    |     /         |   |___)    )   /   /    |  |   /     /    |     /       |");
        System.out.println(" |___|  )____)  /___/     |__|  /_____/     |____/          |___________)   /___/     |__|  /_____/     |____/        |");
        System.out.println("••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••");
        System.out.println("  MARK TASK                                                                                                           |");
        System.out.println("••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••");
        System.out.println("                                                                                                                      |");
        System.out.println("                                                                                                                      |");
        System.out.println("1 - PROJETOS                                                                                                          |");
        System.out.println("2 - CRIAR PROJETO                                                                                                     |");
        System.out.println("3 - CRIAR ATIVIDADE                                                                                                   |");
        System.out.println("4 - CRIAR DATA                                                                                                        |");
        System.out.println("                                                                                                                      |");
        System.out.println("                                                                                                                      |");
        System.out.println("                                                                                                                      |");
        System.out.println("0 - SAIR DO MODO ADIMINISTRADOR                                                                                       |");
        System.out.println(" \n                                                                                                                   |");       
    }
}
