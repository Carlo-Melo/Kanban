package Kanban;

public class Empresa {
    private String nomeUsuario;
    private String senha;
    private String senhaSalva;
    private String[] projetos;
    private String[][] atividades;
    private int[][] porcentagens;
    
    public Empresa(String nomeUsuario, String senha){
        this.nomeUsuario = nomeUsuario;
        this.senha = senha;   
        this.projetos = new String[5];
        this.atividades = new String[5][20];
        this.porcentagens = new int[5][20];
        this.projetos[0] = "Projeto Integrador";
        this.atividades[0][0] = "at";
        this.atividades[0][1] = "at2";
        this.atividades[0][2] = "at3";
        this.atividades[0][3] = "at4";
        this.atividades[0][4] = "at5";
        this.porcentagens[0][0] = 50;
        this.porcentagens[0][1] = 38;
        this.porcentagens[0][0] = 25;
        this.porcentagens[0][0] = 78;
        this.porcentagens[0][0] = 100;
    }
    public String[] getProjetos() {
        return this.projetos;
    }
    
    public String[][] getAtividades() {
        return this.atividades;
    }

    public void setNomeUsuario (String nomeUsuario){
            this.nomeUsuario = nomeUsuario;
        }

    public String getNomeUsuario(){
       return nomeUsuario;              
    }

public void setSenha (String senha) {
        this.senha = senha;
    }

    public String getSenha(){
       return senha;              
    }
    

//    public void cadastrarUsuario() {
//        usuarios.put(this.nomeUsuario,this.senha);
//        System.out.println("Usuário cadastrado com sucesso!");
//    }
//    
      public boolean realizarLogin(String senha) {
        if (this.senha.equals(senha)) {
            System.out.println("Login bem-sucedido! Bem-vindo, " + this.nomeUsuario + ".");
            this.senhaSalva = senha;
            return true;
        } else {
            System.out.println("Nome de usuário ou senha incorretos. Tente novamente.");     
            return false;
        }        
    }

    public void adicionarAtividade(int escolhaProjeto, String nomeAtividade) {
        for (int i = 0; i < this.atividades[escolhaProjeto].length; i++) {
            if (this.atividades[escolhaProjeto][i] == null) {
                this.atividades[escolhaProjeto][i] = nomeAtividade;
                this.porcentagens[escolhaProjeto][i] = 0;
                break;
            }
        }
    }

    public int[][] getPorcentagens() {
        return this.porcentagens;
    }

    void aumentarPorcentagem(int i, int j) {
        this.porcentagens[i][j] += 10;
        if (this.porcentagens[i][j] > 100) {
            this.porcentagens[i][j] = 100;
        }
    }

    void diminuirPorcentagem(int i, int j) {

        this.porcentagens[i][j] -= 10;
        if (this.porcentagens[i][j] < 0) {
            this.porcentagens[i][j] = 0;
        }
    }
}


    

     