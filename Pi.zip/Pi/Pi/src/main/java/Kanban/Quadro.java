package Kanban;


public class Quadro {
    
    public Quadro(){

    }
    public static void quadro(String[] atividades, int[] porcentagens) {

        System.out.println("|========================= =========================== ===========================|");
        System.out.println("•         A FAZER          •         FAZENDO           •          FEITO            •");
        System.out.println("|========================= =========================== ===========================|");
        for (int i = 0; i < atividades.length; i++) {
            if (atividades[i] == null) {
                continue;
            }
            if (porcentagens[i] == 0) {
                System.out.println((i+1)+" - "+atividades[i]+" ("+porcentagens[i]+"%)");
            }
            if (porcentagens[i] > 0 && porcentagens[i] < 100) {
                System.out.println("                             "+(i+1)+" - "+atividades[i]+" ("+porcentagens[i]+"%)");
            }
            if (porcentagens[i] == 100) {
                System.out.println("                                                       "+(i+1)+" - "+atividades[i]+" ("+porcentagens[i]+"%)");
            }
        }
        System.out.println("|=================================================================================|");
    }

}
