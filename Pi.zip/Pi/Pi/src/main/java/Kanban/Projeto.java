package Kanban;

import java.util.ArrayList;
import java.util.Scanner;

public class Projeto {
    
    ArrayList<String> projeto = new ArrayList<>();
    Scanner input = new Scanner(System.in);
    
    private String[] projetos;
    private int n;

    public Projeto(String[] projetos, int n) {
        this.projetos = new String[5];
        this.n = n;
    }
    
    public void setN (int n) {
        this.n = n;
    }
    
    public int getN () {
        return n;
    }
    
    public void setProjetos (String[] projetos) {
         this.projetos = new String[5];    
    }
    
    public String[] getProjetos() {
        return projetos;
    }
    
    //funções
    
    public void CadastrarProjeto(Scanner input){
//        int N = 5;
//        String atividades[] = new String[N];
//        Atividade atividade = new Atividade(atividades, N);
//        for (int i = 0 ; i < 1 ; i++) {  
//            System.out.println("Insira o nome do projeto:");
//            projetos[i] = input.next();
        }
    }

