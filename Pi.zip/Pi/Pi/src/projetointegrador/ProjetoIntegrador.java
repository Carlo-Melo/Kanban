package projetointegrador;
import java.util.Scanner;

public class ProjetoIntegrador {

    //Dentro de uma sessão
    // 0 : Não Alocado;
    // 1 : Disponível;
    // 2 : Ocupada;
    public static void main(String[] args) {
        
        int cinema[][][][] = new int[32][16][64][64];
        String sessões[][][] = new String[32][16][2];
        String ingressos[][] = new String[32 * 16 * 64 * 64][4];
        String filmes[] = new String[128];
        // Ingresso = ["123909321", "mei a"/"inteira", "2.3", "A13"]
        Scanner leitor = new Scanner(System.in);
        setup(cinema, sessões, filmes);
        clearTerminal();
        boolean admin = false;
        while (true) {
            if (!admin) {
                System.out.println("");
                System.out.println("ESCOLHA UMA OPÇÂO: ");
                System.out.println("1 - COMPRAR UM INGRESSO");
                System.out.println("2 - IMPRIMIR INGRESSO");
                System.out.println("");
            }
            if (admin) {
                System.out.println("");
                System.out.println("ESCOLHA UMA OPÇÂO: ");
                System.out.println("1 - CADASTRAR FILME");
                System.out.println("2 - CADASTRAR SALA");
                System.out.println("3 - SELECIONAR SALA");
                System.out.println("4 - GERAR ESTATÍSTICAS");
                System.out.println("0 - VOLTAR AO MODO PARA CLIENTES");
            }
            String opção = leitor.nextLine();
            clearTerminal();
            if ("1".equals(opção) && !admin) {
                buyTickets(leitor, cinema, sessões, filmes, ingressos);
            }
            if ("2".equals(opção) && !admin) {
                System.out.println("Insira o CPF usado para comprar o Ingresso: (-1 cancela])");
                String cpf = leitor.nextLine();
                clearTerminal();
                if ("-1".equals(cpf)) {
                    continue;
                }
                imprimirIngressos(cpf, sessões, ingressos);
                leitor.nextLine();
                clearTerminal();
            }
            

            if ("1".equals(opção) && admin) {
                System.out.println("Insira o nome do filme: ");
                String filmeNome = leitor.nextLine();
                boolean alreadyThere = false;
                for (String filme : filmes) {
                    if (filmeNome.equals(filme)) {
                        alreadyThere = true;
                    }
                }
                if (alreadyThere) {
                    continue;
                }
                for (int i = 0; i < filmes.length; i++) {
                    if (null == filmes[i] || "".equals(filmes[i])) {
                        filmes[i] = filmeNome;
                        break;
                    }
                }

            }

            if ("2".equals(opção) && admin) {
                newRoom(cinema, leitor);
            }

            if ("3".equals(opção) && admin) {
                System.out.println("Selecione uma Sala (-1 para voltar)");
                System.out.println("");
                listRooms(cinema, sessões);
                System.out.println("");
                String selectedRoom = leitor.nextLine();
                if (isNumeric(selectedRoom)) {
                    int numSelectedRoom = Integer.parseInt(selectedRoom) - 1;
                    if (numSelectedRoom >= 0 && numSelectedRoom < 32 && !roomIsUnused(cinema, numSelectedRoom)) {
                        System.out.println("ESCOLHA UMA OPÇÃO: ");
                        System.out.println("1 - REMOVER UMA SESSÃO");
                        System.out.println("2 - ADICIONAR UMA SESSÃO");
                        System.out.println("3 - DELETAR SALA");
                                             
                        System.out.println("0 - VOLTAR AO MENU ANTERIOR");
                        String subSelect = leitor.nextLine();
                        switch (subSelect) {
                            case "1" -> {
                                do {
                                    listSession(sessões, numSelectedRoom);
                                    System.out.println("Selecione alguma sessão: (-1 Cancela)");
                                    String sessãoEscolhida = leitor.nextLine();
                                    if ("-1".equals(sessãoEscolhida)) {
                                        break;
                                    }
                                    if (!isNumeric(sessãoEscolhida)) {
                                        continue;
                                    }
                                    int numSessãoEscolhida = Integer.parseInt(sessãoEscolhida) - 1;
                                    if (numSessãoEscolhida < 0 || numSessãoEscolhida >= 15) {
                                        continue;
                                    }
                                    if (null == sessões[numSelectedRoom][numSessãoEscolhida][0]) {
                                        continue;
                                    }
                                    System.out.printf("Realmente Deseja Remover a Sessão %s? (s/n)\n", sessãoEscolhida);
                                    String confirmação = leitor.nextLine();
                                    if ("s".equals(confirmação)) {
                                        sessões[numSelectedRoom][numSessãoEscolhida][0] = null;
                                        sessões[numSelectedRoom][numSessãoEscolhida][1] = null;
                                        reorganizarSessões(sessões, numSelectedRoom);
                                    }
                                    break;
                                } while (true);
                            }
                            case "2" -> {
                                do {
                                    System.out.println("Selecione um Filme: (-1 cancela)");
                                    listarFilmes(filmes);
                                    String filmeEscolhido = leitor.nextLine();
                                    if ("-1".equals(filmeEscolhido)) {
                                        break;
                                    }
                                    if (isNumeric(filmeEscolhido)) {
                                        int numFilmeEscolhido = Integer.parseInt(filmeEscolhido) - 1;
                                        if (numFilmeEscolhido < 0 || numFilmeEscolhido >= 128) {
                                            continue;
                                        }
                                        if (null == filmes[numFilmeEscolhido] || "".equals(filmes[numFilmeEscolhido])) {
                                            continue;
                                        }
                                        do {
                                            System.out.println("Insira o Horário: (Ex 08:05)");
                                            String horario = leitor.nextLine();
                                            if ("-1".equals(horario)) {
                                                break;
                                            }
                                            if (!horarioIsValido(horario)) {
                                                continue;
                                            }
                                            for (int i = 0; i < sessões[numSelectedRoom].length; i++) {
                                                if (sessões[numSelectedRoom][i][0] == null || sessões[numSelectedRoom][i][1] == null) {
                                                    sessões[numSelectedRoom][i][0] = filmes[numFilmeEscolhido];
                                                    sessões[numSelectedRoom][i][1] = horario;
                                                    break;
                                                }
                                            }
                                            break;
                                        } while(true);
                                                                              
                                    }
                                    if (!isNumeric(filmeEscolhido)) {
                                        continue;
                                    }
                                    break;
                                } while (true);
                            }
                            case "3" -> {
                                System.out.printf("Tem certeza que deseja excluir PERMANENTEMENTE a sala %d? (s/n)\n", numSelectedRoom+1);
                                String confirmação = leitor.nextLine();
                                if ("s".equals(confirmação)) {
                                    deletarSala(cinema, sessões, numSelectedRoom);
                                    System.out.printf("Sala %d DELETADA.", numSelectedRoom+1);
                                } else {
                                    continue;
                                }
                            }
                            case "0" -> {
                            }
                                
                        }
                    }
                }
            }
            if ("4".equals(opção) && admin) {
                gerarEstatísticas(cinema, sessões,ingressos, filmes);
                leitor.nextLine();
            }
            if ("0".equals(opção) && admin) {
                admin = false;
            }

            if ("admin".equalsIgnoreCase(opção) && !admin) {
                System.out.println("Acessando Ferramenta para Gerenciamento");
                System.out.println("Insira a senha: ");
                String pass = leitor.nextLine();
                clearTerminal();
                if ("admin".equals(pass)) {
                    admin = true;
                }
            }
        }
    }

    public static int listRooms(int[][][][] cinema, String sessões[][][]) {
        int roomsInUse = 0;
        for (int i = 0; i < cinema.length; i++) {
            if (!roomIsUnused(cinema, i)) {
                int roomHeigth = 0;
                int roomWidth = 0;
                int numSessions = 0;
                int k = 0;
                roomsInUse++;
                while (cinema[i][0][0][k] != 0) {
                    k++;
                }
                int j = 0;
                while (cinema[i][0][j][0] != 0) {
                    j++;
                }
                int l = 0;
                for (String[] sessão : sessões[i]) {
                    if (null != sessão[0]) {
                        l++;
                    }
                }
                roomHeigth = j;
                roomWidth = k;
                numSessions = l;
                System.out.printf("Sala %d (%dx%d), possui %d sessões cadastradas.\n", (i+1), roomHeigth, roomWidth, numSessions);
            }
        }
        return roomsInUse;
    }

    public static void buyTickets(Scanner leitor, int[][][][] cinema, String[][][] sessões, String[] filmes, String[][] ingressos) {
       
        String opção = "";
        int numOpção = 0;
        do {

            System.out.println("Escolha um Filme");
            for (int i = 0; i < filmes.length; i++) {
                if (null != filmes[i]) {
                    System.out.printf("%d-%s\n", (i + 1), filmes[i]);
                }
            }
            System.out.println("\n0-Cancelar");
            opção = leitor.nextLine();
            clearTerminal();
            if (isNumeric(opção)) {
                numOpção = Integer.parseInt(opção) - 1;
                if ("0".equals(opção)) {
                    return;
                }
                if (filmes[numOpção] == null) {
                   
                    continue;
                }
                int sessõesEncontradas[][] = new int[32][2];
                for (int i = 0; i < sessõesEncontradas.length; i++) {
                    for (int j = 0; j < sessõesEncontradas[i].length; j++) {
                        sessõesEncontradas[i][j] = -1;
                    }
                }
                
                int salaESessão[] = new int[2];
                do {
                    System.out.printf("Sessões Encontradas para o Filme: %S\n",filmes[numOpção]);
                    int numSessões = 0;
                    for (int i = 0; i < cinema.length; i++) {
                        if (!roomIsUnused(cinema, i)) {
                            for (int j = 0; j < sessões[i].length; j++) {
                                if (filmes[numOpção].equals(sessões[i][j][0])) {
                                    System.out.printf("Sala %d | Sessão %d: %s (%s)\n", i+1, j+1, sessões[i][j][0], sessões[i][j][1]);
                                    sessõesEncontradas[numSessões][0] = i;
                                    sessõesEncontradas[numSessões][1] = j;
                                    numSessões++;
                                }
                            }
                        }
                    }
                    System.out.println("");
                    if (sessõesEncontradas[0][0] == -1 && sessõesEncontradas[0][1] == -1) {
                        System.out.println("Nenhuma sala com este filme disponível");
                        break;
                    }
                    System.out.println("Insira a Sala da sessão Desejada: (0-Cancela)");
                    String salaEscolhidaStr = leitor.nextLine();
                    if ("0".equals(salaEscolhidaStr)) {
                        return;
                    }
                    if (!isNumeric(salaEscolhidaStr)) {
                        continue;
                    }
                    int salaEscolhida = Integer.parseInt(salaEscolhidaStr);
                    System.out.println("Agora Insira qual o número da Sessão: (0-Cancela)");
                    String sessãoEscolhidaStr = leitor.nextLine();
                    if ("0".equals(sessãoEscolhidaStr)) {
                        return;
                    }
                    if (!isNumeric(sessãoEscolhidaStr)) {    
                        continue;
                    }
                    int sessãoEscolhida = Integer.parseInt(sessãoEscolhidaStr);
                    if ((salaEscolhida < 0 || salaEscolhida >= 32) || (sessãoEscolhida < 0 || sessãoEscolhida >= 16)) {
                        continue;
                    }
                    if (salaEscolhida == 0 && sessãoEscolhida == 0) {
                        break;
                    }
                    salaESessão[0] = salaEscolhida - 1;
                    salaESessão[1] = sessãoEscolhida - 1;
                    boolean condição1 = false, condição2 = false, condição3 = false;
                    if (checkIfContains(sessõesEncontradas, salaESessão)) {
                        
                        do {
                            clearTerminal();
                            System.out.printf("SALA %d SESSÃO %d", salaESessão[0]+1, salaESessão[1]+1);
                            System.out.println("");
                            System.out.printf("FILME : %S", sessões[salaESessão[0]][salaESessão[1]][0]);
                            System.out.println("");
                            System.out.printf("HORARIO : %S", sessões[salaESessão[0]][salaESessão[1]][1]);
                            System.out.println("");
                            int dimensões[] = printRoom(cinema[salaESessão[0]][salaESessão[1]]);
                            String cpf = "";
                            String tipo = ""; //meia ou inteira
                            String salassesão = String.valueOf(salaEscolhida) + "." + String.valueOf(sessãoEscolhida); // x.y sala X sessão Y
                            String cadeira = ""; // A13 fileira A cadeira 13
                            condição1 = false;
                            condição2 = false;
                            condição3 = false;
                            int posição[] = new int[2];
                            posição[0] = -1;
                            posição[1] = -1;
                            condição1 = false;
                            condição2 = false;
                            condição3 = false;
                            System.out.println("Caso queira cancelar, insira -1 em qualquer campo: ");
                            System.out.println("Insira o CPF: ");
                            cpf = leitor.nextLine();
                            if (isNumeric(cpf)) {
                                condição1 = true;
                            } else if ("-1".equals(cpf)) {
                                clearTerminal();
                                break;
                            }
                            System.out.println("Ingresso do tipo meia entrada? (s/n)");
                            tipo = leitor.nextLine();
                            if ("s".equals(tipo)) {
                                tipo = "meia";
                                condição2 = true;
                            } else if ("n".equals(tipo)) {
                                tipo = "inteira";
                                condição2 = true;
                            } else if ("-1".equals(tipo)) {
                                clearTerminal();
                                break;
                            }
                            System.out.println("Insira a Cadeira Escolhida: (EX: A8)");
                            cadeira = leitor.nextLine();
                            if (cadeiraÉVálida(cadeira)) {
                                posição = parseCadeira(cadeira);
                                if (posição[0] < dimensões[0] && posição[1] < dimensões[1]) {
                                    condição3 = true;
                                }
                                if (cinema[salaESessão[0]][salaESessão[1]][posição[0]][posição[1]] == 2) {
                                    System.out.printf("Cadeira %s NÃO está Disponível.", cadeira);
                                    condição3 = false;
                                    leitor.nextLine();
                                }
                            } else if ("-1".equals(cadeira)) {
                                clearTerminal();
                                break;
                            }
                            if (condição1 && condição2 && condição3) {
                                cinema[salaESessão[0]][salaESessão[1]][posição[0]][posição[1]] = 2;
                                for (int i = 0; i < ingressos.length; i++) {
                                    if (null == ingressos[i][0]) {
                                        ingressos[i][0] = cpf;ingressos[i][1] = tipo;ingressos[i][2] = salassesão;ingressos[i][3] = cadeira;
                                        System.out.printf("Ingresso Comprado e Cadastrado no CPF ( %s )\n", cpf);
                                        leitor.nextLine();
                                        clearTerminal();
                                        break;
                                    }
                                }
                            } else {
                                System.out.println("");
                                if (!condição1) {
                                    System.out.println("CPF Inválido");
                                }
                                if (!condição2) {
                                    System.out.println("Responda a Segunda Pergunta apenas com s ou n");
                                }
                                if (!condição3) {
                                    System.out.println("Cadeira Inválida");
                                }
                                leitor.nextLine();
                                clearTerminal();
                            }
                        } while (!condição1 || !condição2 || !condição3);

                    }
                } while (!checkIfContains(sessõesEncontradas, salaESessão));
            }
        } while (!isNumeric(opção) || null == filmes[numOpção]);
    }

    /*  
    public static void listSessions(int[][][][] cinema, String[][][] sessões) {
       
    }
     */
    public static void newRoom(int[][][][] cinema, Scanner leitor) {
        System.out.println("Insira a quantidade de Fileiras na Sala: ");
        int heigth = Integer.parseInt(leitor.nextLine());
        System.out.println("Insira a quantidade de Assentos por Fileira: ");
        int width = Integer.parseInt(leitor.nextLine());
        
        for (int i = 0; i < cinema.length; i++) {
            if (roomIsUnused(cinema, i)) {
                System.out.printf("Sala %d sendo Criada.\n", (i+1));
                for (int j = 0; j < cinema[i].length; j++) {
                    for (int h = 0; h < heigth; h++) {
                        for (int w = 0; w < width; w++) {
                            cinema[i][j][h][w] = 1;
                        }
                    }
                }
                System.out.printf("Sala %d Criada.", (i+1));
                leitor.nextLine();
                clearTerminal();
                break;
            }
        }
    }

    public static boolean roomIsUnused(int cinema[][][][], int index) {
        boolean isEmpty = true;
        for (int i = 0; i < cinema[index].length; i++) {
            for (int j = 0; j < cinema[index][i].length; j++) {
                for (int k = 0; k < cinema[index][i][j].length; k++) {
                    if (cinema[index][i][j][k] != 0) {
                        isEmpty = false;
                    }
                }
            }
        }
        return isEmpty;
    }

    public static void setup(int[][][][] cinema, String[][][] sessoes, String[] filmes) {
        filmes[0] = "The Flash";
        filmes[1] = "A Pequena Sereia";
        filmes[2] = "Transformers";
        filmes[3] = "Aranhaverso";
        filmes[4] = "Oppenheimer";
        filmes[5] = "Velozes e Furiosos";       
        
        //Sala 0
        createRoom(cinema, 16, 16);
        sessoes[0][0][0] = filmes[4];
        sessoes[0][0][1] = "10:00";

        sessoes[0][1][0] = filmes[1];
        sessoes[0][1][1] = "12:00";

        sessoes[0][2][0] = filmes[5];
        sessoes[0][2][1] = "14:00";

        sessoes[0][3][0] = filmes[4];
        sessoes[0][3][1] = "16:00";

        sessoes[0][4][0] = filmes[1];
        sessoes[0][4][1] = "10:30";

        sessoes[0][5][0] = filmes[2];
        sessoes[0][5][1] = "12:30";

        sessoes[0][6][0] = filmes[4];
        sessoes[0][6][1] = "14:30";

        sessoes[0][7][0] = filmes[3];
        sessoes[0][7][1] = "16:30";

        // Sala 1
        createRoom(cinema, 16, 12);
        sessoes[1][0][0] = filmes[0];
        sessoes[1][0][1] = "10:00";

        sessoes[1][1][0] = filmes[2];
        sessoes[1][1][1] = "12:00";

        sessoes[1][2][0] = filmes[5];
        sessoes[1][2][1] = "14:00";

        sessoes[1][3][0] = filmes[0];
        sessoes[1][3][1] = "16:00";

        sessoes[1][4][0] = filmes[3];
        sessoes[1][4][1] = "10:30";

        sessoes[1][5][0] = filmes[1];
        sessoes[1][5][1] = "12:30";

        sessoes[1][6][0] = filmes[4];
        sessoes[1][6][1] = "14:30";

        sessoes[1][7][0] = filmes[5];
        sessoes[1][7][1] = "16:30";

        // Sala 2
        createRoom(cinema, 12, 16);
        sessoes[2][0][0] = filmes[3];
        sessoes[2][0][1] = "10:00";

        sessoes[2][1][0] = filmes[1];
        sessoes[2][1][1] = "12:00";

        sessoes[2][2][0] = filmes[2];
        sessoes[2][2][1] = "14:00";

        sessoes[2][3][0] = filmes[4];
        sessoes[2][3][1] = "16:00";

        sessoes[2][4][0] = filmes[1];
        sessoes[2][4][1] = "10:30";

        sessoes[2][5][0] = filmes[3];
        sessoes[2][5][1] = "12:30";

        sessoes[2][6][0] = filmes[5];
        sessoes[2][6][1] = "14:30";

        sessoes[2][7][0] = filmes[0];
        sessoes[2][7][1] = "16:30";

        // Sala 3
        createRoom(cinema, 10, 14);
        sessoes[3][0][0] = filmes[4];
        sessoes[3][0][1] = "10:00";

        sessoes[3][1][0] = filmes[0];
        sessoes[3][1][1] = "12:00";

        sessoes[3][2][0] = filmes[5];
        sessoes[3][2][1] = "14:00";

        sessoes[3][3][0] = filmes[2];
        sessoes[3][3][1] = "16:00";

        sessoes[3][4][0] = filmes[3];
        sessoes[3][4][1] = "10:30";

        sessoes[3][5][0] = filmes[1];
        sessoes[3][5][1] = "12:30";

        sessoes[3][6][0] = filmes[4];
        sessoes[3][6][1] = "14:30";

        sessoes[3][7][0] = filmes[0];
        sessoes[3][7][1] = "16:30";

        // Sala 4
        createRoom(cinema, 8, 14);
        sessoes[4][0][0] = filmes[1];
        sessoes[4][0][1] = "10:00";

        sessoes[4][1][0] = filmes[3];
        sessoes[4][1][1] = "12:00";

        sessoes[4][2][0] = filmes[4];
        sessoes[4][2][1] = "14:00";

        sessoes[4][3][0] = filmes[0];
        sessoes[4][3][1] = "16:00";

        sessoes[4][4][0] = filmes[2];
        sessoes[4][4][1] = "10:30";

        sessoes[4][5][0] = filmes[5];
        sessoes[4][5][1] = "12:30";

        sessoes[4][6][0] = filmes[1];
        sessoes[4][6][1] = "14:30";

        sessoes[4][7][0] = filmes[3];
        sessoes[4][7][1] = "16:30";

        // Sala 5
        createRoom(cinema, 22, 32);
        sessoes[5][0][0] = filmes[5];
        sessoes[5][0][1] = "10:00";

        sessoes[5][1][0] = filmes[4];
        sessoes[5][1][1] = "12:00";

        sessoes[5][2][0] = filmes[0];
        sessoes[5][2][1] = "14:00";

        sessoes[5][3][0] = filmes[3];
        sessoes[5][3][1] = "16:00";

        sessoes[5][4][0] = filmes[1];
        sessoes[5][4][1] = "10:30";

        sessoes[5][5][0] = filmes[2];
        sessoes[5][5][1] = "12:30";

        sessoes[5][6][0] = filmes[4];
        sessoes[5][6][1] = "14:30";

        sessoes[5][7][0] = filmes[5];
        sessoes[5][7][1] = "16:30";
    }

    public static boolean isNumeric(String str) {
        return str != null && str.matches("[0-9]+");
    }

    public static int[] printRoom(int[][] room) {
        String alfabeto[] = {"A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "ZA", "ZB", "ZC", "ZD", "ZE", "ZF", "ZG", "ZH", "ZI", "ZJ", "ZK", "ZL", "ZM", "ZN", "ZO", "ZP", "ZQ", "ZR", "ZS", "ZT", "ZU", "ZV", "ZW", "ZX", "ZY", "ZZ", "ZZA", "ZZB", "ZZC", "ZZD", "ZZE", "ZZF", "ZZG", "ZZH", "ZZI", "ZZJ", "ZZK", "ZZL"};
        int rowSize;
        System.out.print("-");
        for (int n = 0; room[0][n] != 0; n++) {
            System.out.print("----");
        }
        System.out.println("");
        System.out.print("   ");
        for (rowSize = 0; room[0][rowSize] != 0; rowSize++) {
            if (rowSize < 9) {
                System.out.printf("%d   ", (rowSize + 1));
            } else {
                System.out.printf("%d  ", (rowSize + 1));
            }
        }
        int width = rowSize;
        System.out.println("");
        int heigth = 0;
        for (int i = 0; i < room.length; i++) {
            if (room[i][0] == 0) {
                heigth = i;
                break;
            }
            System.out.printf("%s  ", alfabeto[i]);
            for (int j = 0; j < room[i].length; j++) {
                if (room[i][j] == 1) {
                    System.out.print("-");
                }
                if (room[i][j] == 2) {
                    System.out.print("X");
                }
                if (room[i][j] == 0) {
                    System.out.println("");
                    break;
                } else {
                    System.out.print("   ");
                }
            }
        }
        System.out.print("-");
        for (int n = 0; room[0][n] != 0; n++) {
            System.out.print("----");
        }
        System.out.println("");
        int dimensions[] = {heigth, width};
        return dimensions;
    }

    public static int[] parseCadeira(String cadeira) {
        String alfabeto[] = {"A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "ZA", "ZB", "ZC", "ZD", "ZE", "ZF", "ZG", "ZH", "ZI", "ZJ", "ZK", "ZL", "ZM", "ZN", "ZO", "ZP", "ZQ", "ZR", "ZS", "ZT", "ZU", "ZV", "ZW", "ZX", "ZY", "ZZ", "ZZA", "ZZB", "ZZC", "ZZD", "ZZE", "ZZF", "ZZG", "ZZH", "ZZI", "ZZJ", "ZZK", "ZZL"};
        String fileira = "";
        int numFileira = 0;
        int coluna = 0;
        int i = 0;
        while (isAlphabetical(cadeira.substring(i, i+1))) {
            fileira += cadeira.substring(i, i+1);
            i++;
        }
        coluna = Integer.parseInt(cadeira.substring(i));
        for (i  = 0; i < alfabeto.length; i++) {
            if (alfabeto[i].equals(fileira)) {
                numFileira = i;
            }
        }
        int position[] = {numFileira, coluna-1};
        return position;
    }

    public static boolean cadeiraÉVálida(String cadeira) {
        if (cadeira.length() == 0) {
            return false;
        }
        if (isNumeric(cadeira.substring(0, 1))) {
            return false;
        }
        int i = 0;
        boolean numberFound = false;
        boolean válida = true;
        while (i < cadeira.length()) {
            if (!isAlphabetical(cadeira.substring(i, (i + 1))) || !isNumeric(cadeira.substring(i, (i + 1)))) {

            }
            if (!numberFound && isNumeric(cadeira.substring(i, (i + 1)))) {
                numberFound = true;
                i++;
                continue;
            }
            if (numberFound && !isNumeric(cadeira.substring(i, (i + 1)))) {
                válida = false;
            }
            i++;

        }
        return válida;
    }

    public static boolean checkIfContains(int[][] a, int[] b) {
        boolean has = false;
        for (int i = 0; i < a.length; i++) {
            if (a[i].length != b.length) {
                has = false;
                continue;
            }
            has = true;
            for (int j = 0; j < b.length; j++) {
                if (a[i][j] != b[j]) {
                    has = false;
                }
            }
            if (has) {
                return has;
            }
        }
        return has;
    }
    public static void clearTerminal() {
        for (int i = 0; i < 50; i++){
            System.out.println("");
        }
    }
    public static boolean isAlphabetical(String str) {
        boolean found = false;
        String alfabeto[] = {"A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "ZA", "ZB", "ZC", "ZD", "ZE", "ZF", "ZG", "ZH", "ZI", "ZJ", "ZK", "ZL", "ZM", "ZN", "ZO", "ZP", "ZQ", "ZR", "ZS", "ZT", "ZU", "ZV", "ZW", "ZX", "ZY", "ZZ", "ZZA", "ZZB", "ZZC", "ZZD", "ZZE", "ZZF", "ZZG", "ZZH", "ZZI", "ZZJ", "ZZK", "ZZL"};
        for (int i = 0; i < str.length(); i++) {
            for (int j = 0; j < alfabeto.length; j++) {
                if (alfabeto[j].equals(str.substring(i, (i + 1)))) {
                    found = true;
                }
            }
            if (found == false) {
                return false;
            }
        }
        return true;
    }

    public static void listSession(String[][][] sessões, int selectedRoom) {
        for (int i = 0; i < sessões[selectedRoom].length; i++) {
            if (null != sessões[selectedRoom][i][0]) {
                System.out.printf("%d-%s (%s)\n", (i+1), sessões[selectedRoom][i][0], sessões[selectedRoom][i][1]);
            }
        }
    }

    public static void reorganizarSessões(String[][][] sessões, int index) {
        String sessõesReorganizadas[][] = new String[16][2];
        for (int i = 0, j = 0; i < sessões[index].length; i++) {
            if (null != sessões[index][i][0] && null != sessões[index][i][0]) {
                sessõesReorganizadas[j][0] = sessões[index][i][0];
                sessõesReorganizadas[j][1] = sessões[index][i][1];
                j++;
            }
        }
        for (int i = 0; i < sessões[index].length; i++) {
            sessões[index][i][0] = null;
            sessões[index][i][1] = null;
        }
        for (int i = 0; i < sessõesReorganizadas.length; i++) {
            sessões[index][i][0] = sessõesReorganizadas[i][0];
            sessões[index][i][1] = sessõesReorganizadas[i][1];
        }
        
    }

    private static boolean horarioIsValido(String horario) {
        if (horario.length() != 5) {
            return false;
        }
        if (horario.charAt(2) != ':' && horario.charAt(2) != ';') {
            return false;
        }
        if (!isNumeric(horario.substring(0,2))) {
            return false;
        }
        if (!isNumeric(horario.substring(3, 5))) {
            return false;
        }
        if (Integer.parseInt(horario.substring(0, 2)) >= 24 || Integer.parseInt(horario.substring(3, 5)) >= 60) {
            return false;
        }
        return true;
    }

    private static void listarFilmes(String[] filmes) {
        for (int i = 0; i < filmes.length; i++) {
            if (null != filmes[i])  {
                System.out.printf("%d-%s\n",(i+1),filmes[i]);
            }
        }
    }

    private static void deletarSala(int[][][][] cinema, String[][][] sessões, int numSelectedRoom) {
        cinema[numSelectedRoom] = new int[16][64][64];
        sessões[numSelectedRoom] = new String[16][2];
    }

    public static void imprimirIngressos(String cpf, String[][][]sessões, String[][]ingressos) {
        boolean háIngressos = false;
        for (int i = 0; i < ingressos.length; i++) {
            if (cpf.equals(ingressos[i][0])) {
                if (háIngressos == false) {
                    háIngressos = true;
                    System.out.printf("Ingressos Encontrados no CPF %s : \n", cpf);
                }
                System.out.println("----------------------------------------------");
                int salasessão[] = parseSalaSessão(ingressos[i][2]);
                int sala = salasessão[0] - 1;
                int sessão = salasessão[1] - 1;
                System.out.printf("Horário: %s\nIngresso do Tipo: %s\nFilme: %s\nSala: %d\nSessão:%d\n",sessões[sala][sessão][1], ingressos[i][1], sessões[sala][sessão][0], (sala+1), (sessão+1));
            }
        }
        if (!háIngressos) {
            System.out.printf("Nenhum Ingresso encontrador para o CPF (%s)\n", cpf);
        }
        System.out.println("----------------------------------------------");
    }
    
    public static int[] parseSalaSessão(String str) {
        int ponto = str.indexOf(".");
        String termo1 = str.substring(0, ponto);
        String termo2 = str.substring(ponto+1);
        int retorno[] = {Integer.parseInt(termo1), Integer.parseInt(termo2)};
        return retorno;
        
    }

    public static void createRoom(int[][][][] cinema, int heigth, int width) {
        for (int i = 0; i < cinema.length; i++) {
            if (roomIsUnused(cinema, i)) {
                for (int j = 0; j < cinema[i].length; j++) {
                    for (int h = 0; h < heigth; h++) {
                        for (int w = 0; w < width; w++) {
                            cinema[i][j][h][w] = 1;
                        }
                    }
                }
                break;
            }
        }
    }

    private static void gerarEstatísticas(int[][][][] cinema, String[][][]sessões,String[][] ingressos, String[] filmes) {
        clearTerminal();
        int[] sessãoMaisPopular = new int[2];
        int qtdSessãoMaisPopular = 0;
        int[] sessãoMenosPopular = new int[2];
        int qtdSessãoMenosPopular = 999;
        int qtdIngressos = 0;
        
        for (int i = 0; i < 32; i++) {
            for (int j =  0; j < 16; j++) {
                qtdIngressos = 0;
                if (null == sessões[i][j][0]) {
                    break;
                }
                for (int m = 0; m < 64; m++) {
                    for (int n = 0; n < 64; n++) {
                        if (cinema[i][j][m][n] == 2) {
                            qtdIngressos++;
                        }
                    }
                }
                if (qtdIngressos >= qtdSessãoMaisPopular) {
                    qtdSessãoMaisPopular = qtdIngressos;
                    sessãoMaisPopular[0] = i; sessãoMaisPopular[1] = j;
                }
                if (qtdIngressos < qtdSessãoMenosPopular) {
                    qtdSessãoMenosPopular = qtdIngressos;
                    sessãoMenosPopular[0] = i; sessãoMenosPopular[1] = j;
                }
            }
        }
        System.out.printf("A sessão Mais Popular foi a sala:  %d, sessão %d\n", sessãoMaisPopular[0]+1, sessãoMaisPopular[1]+1);
        System.out.printf("A sessão Menos Popular foi a sala:  %d, sessão %d\n", sessãoMenosPopular[0]+1, sessãoMenosPopular[1]+1);
    }
}